﻿using System;
using System.Collections.Generic;
using System.IO;

#region Classes Base

abstract class Pessoa
{
    public string Nome;
    public string Telefone;

    public Pessoa(string nome, string telefone)
    {
        Nome = nome;
        Telefone = telefone;
    }
}

#endregion

#region Doador

class Doador : Pessoa
{
    public string Localizacao;
    public string TipoAlimento;
    public int Quantidade;

    public Doador(string nome, string telefone, string localizacao, string tipoAlimento, int quantidade)
        : base(nome, telefone)
    {
        Localizacao = localizacao;
        TipoAlimento = tipoAlimento;
        Quantidade = quantidade;
    }

    public string ToCsv()
    {
        return string.Format("{0},{1},{2},{3},{4}",
            Nome, Telefone, Localizacao, TipoAlimento, Quantidade);
    }

    public static Doador FromCsv(string linha)
    {
        string[] d = linha.Split(',');
        return new Doador(d[0], d[1], d[2], d[3], int.Parse(d[4]));
    }
}

#endregion

#region Beneficiario

class Beneficiario : Pessoa
{
    public string Necessidade;

    public Beneficiario(string nome, string telefone, string necessidade)
        : base(nome, telefone)
    {
        Necessidade = necessidade;
    }

    public string ToCsv()
    {
        return string.Format("{0},{1},{2}", Nome, Telefone, Necessidade);
    }

    public static Beneficiario FromCsv(string linha)
    {
        string[] b = linha.Split(',');
        return new Beneficiario(b[0], b[1], b[2]);
    }
}

#endregion

#region Doacao

class Doacao
{
    public string NomeDoador;
    public string NomeBeneficiario;
    public string TipoAlimento;
    public int Quantidade;

    public Doacao(string doador, string beneficiario, string tipo, int quantidade)
    {
        NomeDoador = doador;
        NomeBeneficiario = beneficiario;
        TipoAlimento = tipo;
        Quantidade = quantidade;
    }

    public string ToCsv()
    {
        return string.Format("{0},{1},{2},{3}",
            NomeDoador, NomeBeneficiario, TipoAlimento, Quantidade);
    }
}

#endregion

#region Programa Principal

class Program
{
    static List<Doador> doadores = new List<Doador>();
    static List<Beneficiario> beneficiarios = new List<Beneficiario>();

    static string doadoresFile = "doadores.csv";
    static string beneficiariosFile = "beneficiarios.csv";
    static string doacoesFile = "doacoes.csv";

    static void Main()
    {
        CarregarDados();

        Console.WriteLine("=== SISTEMA DE DOAÇÃO DE ALIMENTOS ===");

        while (true)
        {
            Console.WriteLine("\n1 - Cadastrar Doador");
            Console.WriteLine("2 - Cadastrar Beneficiário");
            Console.WriteLine("3 - Listar Doações");
            Console.WriteLine("0 - Sair");
            Console.Write("Opção: ");

            string opcao = Console.ReadLine();

            if (opcao == "1") CadastrarDoador();
            else if (opcao == "2") CadastrarBeneficiario();
            else if (opcao == "3") ListarDoacoes();
            else if (opcao == "0") break;
            else Console.WriteLine("Opção inválida!");
        }
    }

    #region Persistencia

    static void CarregarDados()
    {
        if (File.Exists(doadoresFile))
        {
            foreach (string l in File.ReadAllLines(doadoresFile))
                if (l.Trim() != "")
                    doadores.Add(Doador.FromCsv(l));
        }

        if (File.Exists(beneficiariosFile))
        {
            foreach (string l in File.ReadAllLines(beneficiariosFile))
                if (l.Trim() != "")
                    beneficiarios.Add(Beneficiario.FromCsv(l));
        }
    }

    #endregion

    #region Cadastros

    static void CadastrarDoador()
    {
        Console.Write("Nome: ");
        string nome = Console.ReadLine();

        Console.Write("Telefone: ");
        string telefone = Console.ReadLine();

        Console.Write("Localização: ");
        string local = Console.ReadLine();

        Console.Write("Tipo de alimento: ");
        string tipo = Console.ReadLine();

        Console.Write("Quantidade: ");
        int quantidade = int.Parse(Console.ReadLine());

        Doador d = new Doador(nome, telefone, local, tipo, quantidade);
        doadores.Add(d);

        File.AppendAllText(doadoresFile, d.ToCsv() + Environment.NewLine);

        Console.WriteLine("Doador cadastrado com sucesso!");

        VerificarDoacoes();
    }

    static void CadastrarBeneficiario()
    {
        Console.Write("Nome: ");
        string nome = Console.ReadLine();

        Console.Write("Telefone: ");
        string telefone = Console.ReadLine();

        Console.Write("Necessidade: ");
        string necessidade = Console.ReadLine();

        Beneficiario b = new Beneficiario(nome, telefone, necessidade);
        beneficiarios.Add(b);

        File.AppendAllText(beneficiariosFile, b.ToCsv() + Environment.NewLine);

        Console.WriteLine("Beneficiário cadastrado com sucesso!");

        VerificarDoacoes();
    }

    #endregion

    #region Logica de Doacao

    static void VerificarDoacoes()
    {
        foreach (Doador d in doadores)
        {
            if (d.Quantidade <= 0)
                continue;

            foreach (Beneficiario b in beneficiarios)
            {
                if (d.TipoAlimento.ToLower() == b.Necessidade.ToLower())
                {
                    Doacao doacao = new Doacao(
                        d.Nome,
                        b.Nome,
                        d.TipoAlimento,
                        d.Quantidade
                    );

                    File.AppendAllText(doacoesFile, doacao.ToCsv() + Environment.NewLine);

                    Console.WriteLine("Doação automática realizada:");
                    Console.WriteLine(d.Nome + " → " + b.Nome);

                    d.Quantidade = 0;
                    beneficiarios.Remove(b);
                    return;
                }
            }
        }
    }

    #endregion

    #region Listagens

    static void ListarDoacoes()
    {
        if (!File.Exists(doacoesFile))
        {
            Console.WriteLine("Nenhuma doação registrada.");
            return;
        }

        Console.WriteLine("\n=== DOAÇÕES REGISTRADAS ===");
        foreach (string l in File.ReadAllLines(doacoesFile))
        {
            Console.WriteLine(l);
        }
    }

    #endregion
}

#endregion
